<?php
/**
 * This file is a part of the CIDRAM-L package.
 * Homepage: https://cidram.github.io/
 *
 * CIDRAM-L COPYRIGHT 2016 and beyond by Caleb Mazalevskis (Maikuolan).
 *
 * License: GNU/GPLv2
 * @see LICENSE.txt
 *
 * This file: BGPView module (last modified: 2019.12.23).
 */

/** Prevents execution from outside of CIDRAM-L. */
if (!defined('CIDRAM-L')) {
    die('[CIDRAM-L] This should not be accessed directly.');
}

$BGPData = '
// v MODIFY ONLY BELOW THIS LINE v

GB No access from Great Britain allowed
KP No access from North Korea allowed
12345 No access from AS12345 allowed

// ^ MODIFY ONLY ABOVE THIS LINE ^
';



$CIDRAM['InitialiseCacheSection']('BGPView');
$InCache = false;
foreach ([$CIDRAM['ExpandIPv4']($CIDRAM['BlockInfo']['IPAddr']), $CIDRAM['ExpandIPv6']($CIDRAM['BlockInfo']['IPAddr'])] as $Factors) {
    if (!is_array($Factors)) {
        continue;
    }
    foreach ($Factors as $Factor) {
        if (!isset($CIDRAM['BGPView'][$Factor])) {
            continue;
        }
        $InCache = true;
        break 2;
    }
}
if (!$InCache) {
    $Lookup = $CIDRAM['Request']('https://api.bgpview.io/ip/' . $CIDRAM['BlockInfo']['IPAddr']);
    $Lookup = (
        substr($Lookup, 0, 63) === '{"status":"ok","status_message":"Query was successful","data":{' &&
        substr($Lookup, -2) === '}}'
    ) ? json_decode($Lookup, true) : false;
    $CIDRAM['BGPView'][$CIDRAM['BlockInfo']['IPAddr'] . '/32'] = ['ASN' => -1, 'CC' => 'XX'];
    $CIDRAM['BGPView-Modified'] = true;
    if (isset($Lookup['data']['prefixes']) && is_array($Lookup['data']['prefixes'])) {
        foreach ($Lookup['data']['prefixes'] as $Prefix) {
            $Factor = isset($Prefix['prefix']) ? $Prefix['prefix'] : '';
            $ASN = isset($Prefix['asn']['asn']) ? $Prefix['asn']['asn'] : '';
            $CC = isset($Prefix['asn']['country_code']) ? $Prefix['asn']['country_code'] : '';
            if ($Factor && $ASN) {
                $CIDRAM['BGPView'][$Factor] = ['ASN' => $ASN, 'CC' => $CC];
            }
        }
    }
}
foreach ([$CIDRAM['ExpandIPv4']($CIDRAM['BlockInfo']['IPAddr']), $CIDRAM['ExpandIPv6']($CIDRAM['BlockInfo']['IPAddr'])] as $Factors) {
    if (!is_array($Factors)) {
        continue;
    }
    foreach ($Factors as $Factor) {
        if (!isset($CIDRAM['BGPView'][$Factor])) {
            continue;
        }
        foreach (['CC', 'ASN'] as $Attribute) {
            if (!$Attribute) {
                continue;
            }
            if (
                isset($CIDRAM['BGPView'][$Factor][$Attribute]) &&
                ($Pos = strpos($BGPData, "\n" . $CIDRAM['BGPView'][$Factor][$Attribute])) !== false &&
                ($End = strpos($BGPData, "\n", $Pos + 1)) !== false
            ) {
                $Pos += 2 + strlen($CIDRAM['BGPView'][$Factor][$Attribute]);
                $End -= $Pos;
                $CIDRAM['Trigger'](true, substr($BGPData, $Pos, $End));
            }
        }
    }
}
