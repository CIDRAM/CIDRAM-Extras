<?php
/**
 * Plugin Name: CIDRAM
 * Version: 0.4.0
 * Description: CIDRAM (Classless Inter-Domain Routing Access Manager) is a PHP script designed to protect websites by blocking requests originating from IP addresses regarded as being sources of undesirable traffic, including (but not limited to) traffic from non-human access endpoints, cloud services, spambots, scrapers, etc. It does this by calculating the possible CIDRs of the IP addresses supplied from inbound requests and then attempting to match these possible CIDRs against its signature files (these signature files contain lists of CIDRs of IP addresses regarded as being sources of undesirable traffic); If matches are found, the requests are blocked.
 * Author: Caleb Mazalevskis
 * Author URI: https://github.com/Maikuolan
 * Plugin URI: http://maikuolan.github.io/CIDRAM/
 * Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=KTGYGXJETEBYA
 * Contributors: https://github.com/Maikuolan/CIDRAM/graphs/contributors
 * Tags: asn, cidr, cidrs, blocker, anti-spam, cloud, routing, ip, firewall, security, protection
 * License: GPLv2
 * License URI: https://github.com/Maikuolan/CIDRAM/blob/master/LICENSE.txt
 */

/* Execute the loader. */
function wpCIDRAM() {
    require __DIR__ . '/loader.php';
}

/* Register the hook/action. */
add_action('plugins_loaded', 'wpCIDRAM');
